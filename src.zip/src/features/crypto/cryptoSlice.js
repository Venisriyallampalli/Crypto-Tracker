import { createSlice } from '@reduxjs/toolkit';
import { mockCryptoData } from '../../utils/mockData';

// Helper function to generate random price changes
const getRandomPriceChange = (currentPrice) => {
  const changePercent = (Math.random() * 2 - 1) * 0.5; // -0.5% to +0.5%
  return currentPrice * (1 + changePercent / 100);
};

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState: {
    assets: mockCryptoData,
    favorites: [],
    status: 'idle',
    error: null,
  },
  reducers: {
    updatePrices: (state) => {
      state.assets = state.assets.map(asset => {
        const newPrice = getRandomPriceChange(asset.price);
        const priceChange1h = asset.priceChange1h + (Math.random() * 0.1 - 0.05);
        const priceChange24h = asset.priceChange24h + (Math.random() * 0.2 - 0.1);
        const priceChange7d = asset.priceChange7d + (Math.random() * 0.3 - 0.15);
        const volumeChange = 1 + (Math.random() * 0.04 - 0.02);
        const newVolume = asset.volume24h * volumeChange;

        return {
          ...asset,
          price: newPrice,
          priceChange1h,
          priceChange24h,
          priceChange7d,
          volume24h: newVolume,
        };
      });
    },
    toggleFavorite: (state, action) => {
      const assetId = action.payload;
      if (state.favorites.includes(assetId)) {
        state.favorites = state.favorites.filter(id => id !== assetId);
      } else {
        state.favorites.push(assetId);
      }
    },
  },
});

export const { updatePrices, toggleFavorite } = cryptoSlice.actions;
export default cryptoSlice.reducer;