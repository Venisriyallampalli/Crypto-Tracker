import { createSelector } from '@reduxjs/toolkit';

const selectCryptoState = (state) => state.crypto;

export const selectAllCryptoAssets = createSelector(
  [selectCryptoState],
  (cryptoState) => cryptoState.assets
);

export const selectCryptoAssetById = createSelector(
  [selectAllCryptoAssets, (_, id) => id],
  (assets, id) => assets.find(asset => asset.id === id)
);

export const selectFavorites = createSelector(
  [selectCryptoState],
  (cryptoState) => cryptoState.favorites
);

export const selectCryptoStatus = createSelector(
  [selectCryptoState],
  (cryptoState) => cryptoState.status
);

export const selectCryptoError = createSelector(
  [selectCryptoState],
  (cryptoState) => cryptoState.error
);