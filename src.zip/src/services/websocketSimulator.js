import { store } from '../store';
import { updatePrices } from '../features/crypto/cryptoSlice';

class WebSocketSimulator {
  constructor(updateFrequency = 1500) {
    this.updateFrequency = updateFrequency;
    this.interval = null;
  }

  connect() {
    if (this.interval) return;

    // Simulate WebSocket connection by updating prices at regular intervals
    this.interval = window.setInterval(() => {
      store.dispatch(updatePrices());
    }, this.updateFrequency);

    console.log('WebSocket simulator connected');
  }

  disconnect() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
      console.log('WebSocket simulator disconnected');
    }
  }
}

export default new WebSocketSimulator();
