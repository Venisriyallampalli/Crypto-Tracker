import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store';
import CryptoTable from './components/CryptoTable/CryptoTable';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';

function App() {
  return (
    <Provider store={store}>
      <div className="flex flex-col min-h-screen bg-gray-50">
        <Header />
        
        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-4 py-5 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800">Cryptocurrency Prices</h2>
              <p className="text-gray-500 mt-1">Real-time price updates from the crypto market</p>
            </div>
            
            <CryptoTable />
          </div>
        </main>
        
        <Footer />
      </div>
    </Provider>
  );
}

export default App;