// Format number to currency
export const formatCurrency = (value) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: value >= 1 ? 2 : 6,
    maximumFractionDigits: value >= 1 ? 2 : 6,
  }).format(value);
};

// Format large numbers with abbreviations (K, M, B, T)
export const formatLargeNumber = (value) => {
  if (value === 0) return '0';

  const tiers = [
    { threshold: 1e12, suffix: 'T' },
    { threshold: 1e9, suffix: 'B' },
    { threshold: 1e6, suffix: 'M' },
    { threshold: 1e3, suffix: 'K' },
  ];

  const tier = tiers.find(tier => value >= tier.threshold);

  if (tier) {
    const scaled = value / tier.threshold;
    const formatted = scaled.toFixed(2);
    return `$${formatted}${tier.suffix}`;
  }

  return value.toFixed(2);
};

// Format percentage with sign and 2 decimal places
export const formatPercentage = (value) => {
  const formatted = Math.abs(value).toFixed(2);
  const sign = value >= 0 ? '+' : '-';
  return `${sign}${formatted}%`;
};

// Format supply numbers with abbreviated units
export const formatSupply = (value, symbol) => {
  return `${value.toFixed(2)}M ${symbol}`;
};

// Format percentage for coloring (positive/negative)
export const getPriceChangeClass = (value) => {
  return value >= 0 ? 'text-green-500' : 'text-red-500';
};

// Format number with specific decimal places
export const formatNumber = (value, decimals = 2) => {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

// Format volume with currency and abbreviation
export const formatVolume = (volume, symbol) => {
  const formattedVolume = formatLargeNumber(volume);
  return `${formattedVolume}\n${symbol}`;
};
