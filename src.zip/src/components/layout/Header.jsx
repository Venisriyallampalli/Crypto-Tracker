import React from 'react';
import { BarChart4, Search } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <BarChart4 className="text-blue-600 h-8 w-8 mr-2" />
          <h1 className="text-xl font-bold text-gray-900">CryptoTracker</h1>
        </div>

        <div className="hidden md:flex items-center">
          <div className="relative">
            <input
              type="text"
              placeholder="Search cryptocurrency"
              className="py-2 pl-10 pr-4 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          </div>

          <button className="ml-4 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition duration-200">
            Connect Wallet
          </button>
        </div>

        <button className="md:hidden text-gray-600">
          <Search className="h-6 w-6" />
        </button>
      </div>
    </header>
  );
};

export default Header;
