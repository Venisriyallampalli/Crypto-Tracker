import React, { useState } from 'react';
import { Info } from 'lucide-react';

const InfoIcon = ({ tooltipText }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="relative inline-block ml-1">
      <Info 
        size={16} 
        className="text-gray-400 cursor-help"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
      />
      
      {showTooltip && (
        <div className="absolute z-10 w-64 bg-gray-800 text-white text-sm rounded py-1 px-2 -left-1/2 -translate-x-1/2 bottom-full mb-1 shadow-lg">
          {tooltipText}
          <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 rotate-45 bg-gray-800"></div>
        </div>
      )}
    </div>
  );
};

export default InfoIcon;
