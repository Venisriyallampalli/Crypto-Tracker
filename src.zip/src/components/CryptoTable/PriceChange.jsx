import React from 'react';
import { formatPercentage } from '../../utils/formatters';
import { ArrowUp, ArrowDown } from 'lucide-react';

const PriceChange = ({ value }) => {
  const colorClass = value >= 0 ? 'text-green-500' : 'text-red-500';
  const Icon = value >= 0 ? ArrowUp : ArrowDown;

  return (
    <div className={`flex items-center ${colorClass} whitespace-nowrap`}>
      <Icon className="mr-1" size={16} />
      <span>{formatPercentage(value)}</span>
    </div>
  );
};

export default PriceChange;
