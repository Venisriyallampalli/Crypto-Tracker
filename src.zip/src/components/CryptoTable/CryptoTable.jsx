import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectAllCryptoAssets } from '../../features/crypto/cryptoSelectors';
import CryptoRow from './CryptoRow';
import InfoIcon from './InfoIcon';
import websocketSimulator from '../../services/websocketSimulator';

const CryptoTable = () => {
  const assets = useSelector(selectAllCryptoAssets);
  const dispatch = useDispatch();
  
  useEffect(() => {
    websocketSimulator.connect();
    return () => {
      websocketSimulator.disconnect();
    };
  }, [dispatch]);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr>
            <th className="py-3 px-2 text-center">&nbsp;</th>
            <th className="py-3 px-2 text-center text-gray-500 text-xs font-medium tracking-wider">#</th>
            <th className="py-3 px-6 text-left text-gray-500 text-xs font-medium tracking-wider">Name</th>
            <th className="py-3 px-6 text-right text-gray-500 text-xs font-medium tracking-wider">Price</th>
            <th className="py-3 px-4 text-right text-gray-500 text-xs font-medium tracking-wider">1h %</th>
            <th className="py-3 px-4 text-right text-gray-500 text-xs font-medium tracking-wider">24h %</th>
            <th className="py-3 px-4 text-right text-gray-500 text-xs font-medium tracking-wider">7d %</th>
            <th className="py-3 px-6 text-right text-gray-500 text-xs font-medium tracking-wider">
              <div className="flex items-center justify-end">
                Market Cap
                <InfoIcon tooltipText="Market Cap = Current Price x Circulating Supply" />
              </div>
            </th>
            <th className="py-3 px-6 text-right text-gray-500 text-xs font-medium tracking-wider">
              <div className="flex items-center justify-end">
                Volume(24h)
                <InfoIcon tooltipText="A measure of how much of a cryptocurrency was traded in the last 24 hours." />
              </div>
            </th>
            <th className="py-3 px-6 text-right text-gray-500 text-xs font-medium tracking-wider">
              <div className="flex items-center justify-end">
                Circulating Supply
                <InfoIcon tooltipText="The amount of coins that are circulating in the market and are in public hands." />
              </div>
            </th>
            <th className="py-3 px-6 text-left text-gray-500 text-xs font-medium tracking-wider">Last 7 Days</th>
          </tr>
        </thead>
        <tbody>
          {assets.map((asset) => (
            <CryptoRow key={asset.id} asset={asset} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CryptoTable;
