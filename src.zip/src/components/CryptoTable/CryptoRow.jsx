import React, { memo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PriceChange from './PriceChange';
import MiniChart from './MiniChart';
import { formatCurrency, formatLargeNumber, formatSupply } from '../../utils/formatters';
import { Star } from 'lucide-react';
import { toggleFavorite } from '../../features/crypto/cryptoSlice';
import { selectFavorites } from '../../features/crypto/cryptoSelectors';

const CryptoRow = ({ asset }) => {
  const dispatch = useDispatch();
  const favorites = useSelector(selectFavorites);
  const isFavorite = favorites.includes(asset.id);

  const getTrend = (change) => {
    if (change > 0.1) return 'up';
    if (change < -0.1) return 'down';
    return 'stable';
  };

  const handleToggleFavorite = () => {
    dispatch(toggleFavorite(asset.id));
  };

  return (
    <tr className="border-b border-gray-200 hover:bg-gray-50">
      <td className="py-4 px-2 text-center">
        <Star 
          size={16} 
          className={`cursor-pointer ${isFavorite ? 'text-yellow-400' : 'text-gray-300 hover:text-gray-400'}`}
          fill={isFavorite ? "#facc15" : "transparent"}
          stroke={isFavorite ? "#facc15" : "currentColor"}
          onClick={handleToggleFavorite}
        />
      </td>
      <td className="py-4 px-2 text-center">{asset.rank}</td>
      <td className="py-4 px-6">
  <div className="flex items-center">
    <img 
      src={asset.logo} 
      alt={`${asset.name} logo`} 
      className="w-8 h-8 mr-3 object-contain"
    />
    <div>
      <div className="font-medium">{asset.name}</div>
      <div className="text-gray-500 text-sm">{asset.symbol}</div>
    </div>
  </div>
</td>

      <td className="py-4 px-6 font-medium">{formatCurrency(asset.price)}</td>
      <td className="py-4 px-4"><PriceChange value={asset.priceChange1h} /></td>
      <td className="py-4 px-4"><PriceChange value={asset.priceChange24h} /></td>
      <td className="py-4 px-4"><PriceChange value={asset.priceChange7d} /></td>
      <td className="py-4 px-6">{formatLargeNumber(asset.marketCap)}</td>
      <td className="py-4 px-6">
        <div className="flex flex-col">
          <span>{formatLargeNumber(asset.volume24h)}</span>
          <span className="text-gray-500 text-sm">{(asset.volume24h / asset.price).toFixed(2)} {asset.symbol}</span>
        </div>
      </td>
      <td className="py-4 px-6">
        <div className="flex flex-col">
          <span>{formatSupply(asset.circulatingSupply, asset.symbol)}</span>
          {asset.maxSupply && (
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
              <div 
                className="bg-blue-600 h-1.5 rounded-full" 
                style={{ width: `${(asset.circulatingSupply / asset.maxSupply) * 100}%` }}
              ></div>
            </div>
          )}
        </div>
      </td>
      <td className="py-4 px-6 min-w-[120px]">
        <MiniChart 
          data={asset.chartData} 
          trend={getTrend(asset.priceChange7d)} 
        />
      </td>
    </tr>
  );
};

export default memo(CryptoRow);