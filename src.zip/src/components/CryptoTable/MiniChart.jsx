import React from 'react';

const MiniChart = ({ data, trend }) => {
  if (!data || data.length === 0) {
    return <div className="h-10 w-full bg-gray-100 rounded"></div>;
  }

  // Find min and max for scaling
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min;

  // Normalize data to fit in container
  const normalizedData = data.map(value =>
    range === 0 ? 50 : 100 - ((value - min) / range) * 100
  );

  // Get points for SVG path
  const points = normalizedData
    .map((value, index) => `${(index / (data.length - 1)) * 100},${value}`)
    .join(' ');

  const chartColor = trend === 'up' ? '#16C784' : trend === 'down' ? '#EA3943' : '#8A92B2';

  return (
    <div className="h-10 w-full">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-full w-full">
        <polyline
          points={points}
          fill="none"
          stroke={chartColor}
          strokeWidth="2"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};

export default MiniChart;
